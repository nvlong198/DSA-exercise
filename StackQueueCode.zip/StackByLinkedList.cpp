#include <iostream>
#include <stdexcept>
using namespace std;
struct Node{
    int element;
    Node* next;
    Node* pre;
};
class Stack{
public:
    Stack(){
        head = NULL;
        tail = NULL;
        stackSize = 0;
    }
    void push(int value){
        Node *tmp = new Node;
        tmp->element = value;
        tmp->next = NULL;
        tmp->pre = NULL;
        // If stack is empty
        if (head == NULL){
            head = tmp;
            tail = tmp;
        } else {
            tail->next = tmp;
            tmp->pre = tail;
            tail = tmp;
        }
        stackSize += 1; // stackSize = stackSize + 1;
    }
    int pop(){
        if (head == NULL){
            throw out_of_range("Invalid operation: Stack is empty");
        } else if (head->next == NULL){
            int result = head->element;
            head = NULL;
            tail = NULL;
            stackSize --;
            return result;
        } else
        {
            int result = tail->element;
            tail = tail->pre;
            tail->next = NULL;
            stackSize --;
            return result;
        }
    }
private:
    Node *head, *tail;
    int stackSize;
};
int main(){
    Stack a = Stack();
    a.push(10);
    a.push(5);
    a.push(1);
    cout << a.pop() << endl;
    cout << a.pop() << endl;
    cout << a.pop() << endl;
    return 0;
}

